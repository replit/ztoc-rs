mod zinfo;

fn main() {
    println!("Hello, world!");
}
